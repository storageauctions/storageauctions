/**
 * SSA Components — Shared UI Injection
 * =====================================
 * Injects nav, footer, modals and toast styles into every page.
 * Call SSAComponents.init(config) at page load.
 */
const SSAComponents = (function() {
  'use strict';

  function injectStyles() {
    if (document.getElementById('ssa-component-styles')) return;
    const style = document.createElement('style');
    style.id = 'ssa-component-styles';
    style.textContent = `
      /* Toast */
      .ssa-toast-container{position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:10px;pointer-events:none}
      .ssa-toast{background:var(--navy,#0B2545);color:#fff;padding:13px 18px;border-radius:10px;font-size:.875rem;font-weight:500;box-shadow:0 12px 40px rgba(11,37,69,.25);display:flex;align-items:center;gap:10px;pointer-events:all;animation:ssaToastIn .25s cubic-bezier(.4,0,.2,1);max-width:340px;transition:opacity .3s,transform .3s}
      .ssa-toast--success{background:var(--success,#16A34A)}
      .ssa-toast--danger{background:var(--danger,#DC2626)}
      .ssa-toast--warning{background:var(--warning,#D97706)}
      .ssa-toast__icon{width:20px;height:20px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:.75rem;flex-shrink:0}
      @keyframes ssaToastIn{from{transform:translateX(110%);opacity:0}to{transform:translateX(0);opacity:1}}
      /* Confirm Dialog */
      .ssa-confirm-overlay{position:fixed;inset:0;background:rgba(11,37,69,.55);backdrop-filter:blur(4px);z-index:8000;display:flex;align-items:center;justify-content:center;padding:20px}
      .ssa-confirm{background:#fff;border-radius:16px;padding:28px;max-width:420px;width:100%;box-shadow:0 24px 64px rgba(11,37,69,.2)}
      .ssa-confirm__icon{font-size:2rem;margin-bottom:14px}
      .ssa-confirm__title{font-size:1.1rem;font-weight:800;color:var(--navy,#0B2545);margin-bottom:8px}
      .ssa-confirm__body{font-size:.875rem;color:var(--muted,#64748B);line-height:1.7;margin-bottom:22px}
      .ssa-confirm__actions{display:flex;gap:10px;justify-content:flex-end}
    `;
    document.head.appendChild(style);
  }

  function navHTML(config) {
    const { active='', user=null } = config;
    const liveCount = (SSA.auctions.list({ status:'live' }).length + SSA.auctions.list({ status:'ending' }).length);
    let userMenu = '';
    if (user && user.role === 'buyer') {
      userMenu = `<a href="/buyer/" class="btn btn-outline btn-sm">👤 ${user.name?.split(' ')[0]||'Portal'}</a><button onclick="SSA.Auth.logout();location.href='/buyer/'" class="btn btn-ghost btn-sm">Log Out</button>`;
    } else if (user && user.role === 'operator') {
      userMenu = `<a href="/operator/" class="btn btn-outline btn-sm">🏢 Operator</a><button onclick="SSA.Auth.logout();location.href='/operator/'" class="btn btn-ghost btn-sm">Log Out</button>`;
    } else if (user && user.role === 'superadmin') {
      userMenu = `<span class="badge badge-featured" style="font-size:.65rem">ADMIN</span><button onclick="SSA.Auth.logout();location.href='/admin/'" class="btn btn-ghost btn-sm">Log Out</button>`;
    } else {
      userMenu = `<a href="/buyer/" class="btn btn-outline btn-sm">Log In</a><a href="/buyer/" class="btn btn-primary btn-sm">Register Free</a>`;
    }
    const links = [
      { href:'/auctions/', label:'Auctions', key:'auctions' },
      { href:'/blog/', label:'Blog', key:'blog' },
      { href:'/operator/', label:'For Operators', key:'operator' },
      { href:'/contact/', label:'Help', key:'contact' },
    ];
    return `
    <nav class="nav" id="ssa-nav">
      <div class="nav__inner">
        <a href="/" class="nav__logo">
          <div class="nav__logo-mark">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="1" y="5" width="16" height="11" rx="2" stroke="#F4A233" stroke-width="1.5"/><path d="M5 5V4a4 4 0 0 1 8 0v1" stroke="#F4A233" stroke-width="1.5" stroke-linecap="round"/><circle cx="9" cy="10.5" r="1.5" fill="#F4A233"/></svg>
          </div>
          <span class="nav__logo-text">SelfStorage<span>Auctions</span></span>
        </a>
        <div class="nav__links">
          ${links.map(l=>`<a href="${l.href}" class="nav__link${active===l.key?' active':''}">${l.label}</a>`).join('')}
        </div>
        <div class="nav__actions">
          <span class="nav__live">🔴 ${liveCount} Live</span>
          ${userMenu}
        </div>
        <button class="nav__hamburger" aria-label="Toggle menu" onclick="document.querySelector('.nav__mobile').classList.toggle('open')">
          <span></span><span></span><span></span>
        </button>
      </div>
      <div class="nav__mobile" role="navigation" aria-label="Mobile navigation">
        ${links.map(l=>`<a href="${l.href}" class="nav__link${active===l.key?' active':''}">${l.label}</a>`).join('')}
        <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px">${userMenu}</div>
      </div>
    </nav>`;
  }

  function footerHTML() {
    const c = SSA.content.get('global') || {};
    return `
    <footer class="footer" role="contentinfo">
      <div class="container">
        <div class="footer__grid">
          <div>
            <div class="footer__brand-name">SelfStorage<span>Auctions</span>.com.au</div>
            <div class="footer__tagline">${c.tagline || 'Hunt. Find. Bid. Score.'}</div>
            <p class="footer__desc">${c.footer_desc || 'Australia\'s modern, transparent self storage auction platform.'}</p>
            <div class="footer__badge">🔒 ${c.ssl_badge || 'SSL Secured · Australian Owned & Operated'}</div>
          </div>
          <div>
            <div class="footer__col-title">For Buyers</div>
            <div class="footer__links">
              <a href="/auctions/">Browse Auctions</a>
              <a href="/buyer/">Buyer Portal</a>
              <a href="/buyer/#alerts">Auction Alerts</a>
              <a href="/buyer/#autobid">Auto-Bid</a>
              <a href="/contact/#faq">FAQs</a>
            </div>
          </div>
          <div>
            <div class="footer__col-title">For Operators</div>
            <div class="footer__links">
              <a href="/operator/">Operator Portal</a>
              <a href="/operator/#pricing">Pricing</a>
              <a href="/operator/#register">Register Facility</a>
              <a href="/operator/#reports">Reports</a>
              <a href="/contact/">Support</a>
            </div>
          </div>
          <div>
            <div class="footer__col-title">Company</div>
            <div class="footer__links">
              <a href="/blog/">Blog</a>
              <a href="/contact/">Contact</a>
              <a href="/terms/">Terms & Conditions</a>
              <a href="/terms/#privacy">Privacy Policy</a>
              <a href="/admin/" style="opacity:.4;font-size:.75rem">Admin</a>
            </div>
          </div>
        </div>
        <div class="footer__bottom">
          <div class="footer__copy">© ${new Date().getFullYear()} SelfStorageAuctions.com.au · ABN ${SSA.settings.get('abn')||'XX XXX XXX XXX'} · All rights reserved</div>
          <div class="footer__legal">
            <a href="/terms/">Terms</a>
            <a href="/terms/#privacy">Privacy</a>
            <a href="/terms/#auction-rules">Auction Rules</a>
          </div>
        </div>
      </div>
    </footer>`;
  }

  function bidModalHTML() {
    return `
    <div class="modal-overlay" id="bidModalOverlay" role="dialog" aria-modal="true" aria-labelledby="bidModalTitle" onclick="if(event.target===this)SSAComponents.closeBidModal()">
      <div class="modal modal--wide" id="bidModal">
        <div class="modal__header">
          <h2 class="modal__title" id="bidModalTitle">Place a Bid</h2>
          <button class="modal__close" onclick="SSAComponents.closeBidModal()" aria-label="Close">✕</button>
        </div>
        <div class="modal__body">
          <input type="hidden" id="bidAuctionId"/>
          <div id="bidAuctionInfo" style="background:var(--cloud);border-radius:10px;padding:14px;margin-bottom:20px">
            <div style="font-size:.75rem;font-weight:700;color:var(--amber);margin-bottom:4px" id="bidFacilityLabel"></div>
            <p style="font-size:.84rem;color:var(--muted);margin:0" id="bidDescription"></p>
          </div>
          <div class="field-row" style="margin-bottom:20px">
            <div class="card-flat" style="text-align:center">
              <div style="font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);margin-bottom:6px">Current Bid</div>
              <div style="font-size:1.6rem;font-weight:800;color:var(--amber)" id="bidCurrentVal">$0.00</div>
            </div>
            <div class="card-flat" style="text-align:center">
              <div style="font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);margin-bottom:6px">Minimum Next Bid</div>
              <div style="font-size:1.6rem;font-weight:800;color:var(--navy)" id="bidMinVal">$0.00</div>
            </div>
            <div class="card-flat" style="text-align:center">
              <div style="font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);margin-bottom:6px">Total if You Win</div>
              <div style="font-size:1.6rem;font-weight:800;color:var(--navy)" id="bidTotalVal">$0.00</div>
            </div>
          </div>
          <div id="bidNotLoggedIn" style="display:none">
            <div class="alert alert-warning"><span class="alert-icon">⚠️</span><span>You need to <a href="/buyer/" style="color:var(--warning);font-weight:700">register or log in</a> to place a bid.</span></div>
          </div>
          <div id="bidLoggedIn">
            <div class="form-group">
              <label for="bidAmount">Your Bid ($AUD)</label>
              <div class="input-group">
                <span style="display:flex;align-items:center;padding:0 12px;background:var(--cloud);border:1.5px solid var(--border);border-right:none;border-radius:10px 0 0 10px;font-weight:700;color:var(--muted)">$</span>
                <input type="number" class="form-control" id="bidAmount" placeholder="Enter bid amount" min="0" step="1" oninput="SSAComponents.updateBidCalc()" aria-describedby="bidAmountHint"/>
                <button class="btn btn-primary" onclick="SSAComponents.submitBid()">Place Bid</button>
              </div>
              <div class="form-hint" id="bidAmountHint">Buyer's premium of <span id="bidPremiumPct">10</span>% applies on top of winning bid. <span id="bidGSTNote">GST inclusive.</span></div>
            </div>
            <div class="divider"></div>
            <div class="form-group">
              <label for="autobidAmount">Auto-Bid Maximum ($AUD) — <em style="font-weight:400;color:var(--muted)">optional</em></label>
              <div class="input-group">
                <span style="display:flex;align-items:center;padding:0 12px;background:var(--cloud);border:1.5px solid var(--border);border-right:none;border-radius:10px 0 0 10px;font-weight:700;color:var(--muted)">$</span>
                <input type="number" class="form-control" id="autobidAmount" placeholder="Set your maximum — we bid for you automatically" min="0" step="1"/>
                <button class="btn btn-navy" onclick="SSAComponents.submitAutoBid()">Set Auto-Bid</button>
              </div>
              <div class="form-hint">We'll automatically bid the minimum increment needed to keep you winning, up to your maximum.</div>
            </div>
          </div>
        </div>
      </div>
    </div>`;
  }

  function openBidModal(auctionId) {
    const a = SSA.auctions.get(auctionId);
    if (!a) return;
    const user = SSA.Auth.getSession();
    const settings = SSA.settings.getAll();
    const increment = SSA.auctions.list().find(x=>x.id===auctionId) ? SSA.SEED.settings.min_bid_increments[0].increment : 5;
    const minBid = a.bid + 5; // Simplified for demo
    const calc = SSA.auctions.calculateTotal(minBid);

    document.getElementById('bidAuctionId').value = auctionId;
    document.getElementById('bidModalTitle').textContent = a.name;
    document.getElementById('bidFacilityLabel').textContent = `${a.facility} · ${a.suburb}, ${a.state}`;
    document.getElementById('bidDescription').textContent = a.description;
    document.getElementById('bidCurrentVal').textContent = SSA.formatCurrency(a.bid);
    document.getElementById('bidMinVal').textContent = SSA.formatCurrency(minBid);
    document.getElementById('bidTotalVal').textContent = SSA.formatCurrency(calc.total);
    document.getElementById('bidPremiumPct').textContent = settings.buyer_premium_pct;
    document.getElementById('bidGSTNote').textContent = settings.gst_inclusive ? 'GST inclusive.' : 'GST exclusive.';
    document.getElementById('bidAmount').value = '';
    document.getElementById('bidAmount').min = minBid;
    document.getElementById('autobidAmount').value = '';

    if (!user || user.role === 'superadmin') {
      document.getElementById('bidLoggedIn').style.display = 'none';
      document.getElementById('bidNotLoggedIn').style.display = 'block';
    } else {
      document.getElementById('bidLoggedIn').style.display = 'block';
      document.getElementById('bidNotLoggedIn').style.display = 'none';
    }
    document.getElementById('bidModalOverlay').classList.add('open');
    document.getElementById('bidAmount').focus();
  }

  function closeBidModal() {
    document.getElementById('bidModalOverlay').classList.remove('open');
  }

  function updateBidCalc() {
    const amount = parseFloat(document.getElementById('bidAmount').value) || 0;
    if (amount > 0) {
      const calc = SSA.auctions.calculateTotal(amount);
      document.getElementById('bidTotalVal').textContent = SSA.formatCurrency(calc.total);
    }
  }

  function submitBid() {
    const user = SSA.Auth.getSession();
    if (!user) { SSA.toast('Please log in to bid', 'danger'); return; }
    const auctionId = document.getElementById('bidAuctionId').value;
    const amount = parseFloat(document.getElementById('bidAmount').value);
    if (!amount || isNaN(amount)) { SSA.toast('Please enter a valid bid amount', 'warning'); return; }
    const result = SSA.auctions.bid(auctionId, user.id, amount);
    if (!result.ok) { SSA.toast(result.error, 'danger'); return; }
    closeBidModal();
    SSA.toast(`Bid of ${SSA.formatCurrency(amount)} placed successfully! 🎉`, 'success');
    // Refresh page auction cards if present
    if (window.refreshAuctions) window.refreshAuctions();
  }

  function submitAutoBid() {
    const user = SSA.Auth.getSession();
    if (!user) { SSA.toast('Please log in to set auto-bid', 'danger'); return; }
    const auctionId = document.getElementById('bidAuctionId').value;
    const max = parseFloat(document.getElementById('autobidAmount').value);
    if (!max || max <= 0) { SSA.toast('Please enter a valid maximum', 'warning'); return; }
    SSA.auctions.setAutoBid(auctionId, user.id, max);
    closeBidModal();
    SSA.toast(`Auto-bid set to ${SSA.formatCurrency(max)} 🤖`, 'success');
  }

  function confirm(opts) {
    return new Promise((resolve) => {
      let overlay = document.getElementById('ssa-confirm-overlay');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'ssa-confirm-overlay';
        overlay.className = 'ssa-confirm-overlay';
        document.body.appendChild(overlay);
      }
      overlay.innerHTML = `
        <div class="ssa-confirm" role="alertdialog" aria-modal="true">
          <div class="ssa-confirm__icon">${opts.icon||'⚠️'}</div>
          <div class="ssa-confirm__title">${opts.title||'Are you sure?'}</div>
          <div class="ssa-confirm__body">${opts.body||''}</div>
          <div class="ssa-confirm__actions">
            <button class="btn btn-outline" id="confirmNo">${opts.cancelText||'Cancel'}</button>
            <button class="btn btn-${opts.type||'danger'}" id="confirmYes">${opts.confirmText||'Confirm'}</button>
          </div>
        </div>`;
      overlay.style.display = 'flex';
      document.getElementById('confirmYes').onclick = () => { overlay.style.display='none'; resolve(true); };
      document.getElementById('confirmNo').onclick = () => { overlay.style.display='none'; resolve(false); };
    });
  }

  function auctionCardHTML(a, opts = {}) {
    const wl = SSA.Auth.getSession() ? SSA.watchlist.get(SSA.Auth.getSession().id) : [];
    const watching = wl.includes(a.id);
    const featured = a.featured && opts.showFeatured;
    const statusBadge = { live:'badge-live', ending:'badge-ending', new:'badge-new' }[a.status] || 'badge-new';
    const statusText = { live:'LIVE', ending:'ENDING SOON', new:'NEW' }[a.status] || a.status.toUpperCase();
    return `
    <article class="auction-card${featured?' auction-card--featured':''}" onclick="SSAComponents.openBidModal('${a.id}')" role="button" tabindex="0" aria-label="View and bid on ${a.name}">
      <div class="auction-card__img" aria-hidden="true">
        <span style="font-size:54px">${a.emoji}</span>
        <div class="auction-card__img-overlay"></div>
        <div class="auction-card__badges">
          <span class="badge ${statusBadge}">${statusText}</span>
          ${a.relisted ? '<span class="badge badge-new">RELISTED</span>' : ''}
        </div>
        ${featured ? '<div class="auction-card__featured-banner">⭐ Featured</div>' : ''}
        <button class="auction-card__watch ${watching?'active':''}" 
          onclick="event.stopPropagation();SSAComponents.toggleWatch('${a.id}',this)" 
          aria-label="${watching?'Remove from':'Add to'} watchlist">${watching?'❤️':'🤍'}</button>
      </div>
      <div class="auction-card__body">
        <div class="auction-card__facility">${a.facility}</div>
        <h3 class="auction-card__name">${a.name}</h3>
        <div class="auction-card__loc">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          ${a.suburb}, ${a.state}
        </div>
        <div class="auction-card__bids"><strong>${a.bids} bids</strong> · ${a.watchers} watching${a.viewable?' · Viewing available':''}</div>
        <div class="auction-card__hr"></div>
        <div class="auction-card__foot">
          <div>
            <div class="auction-card__bid-lbl">Current Bid</div>
            <div class="auction-card__bid-val">${SSA.formatCurrency(a.bid)}</div>
          </div>
          <div>
            <div class="auction-card__timer-lbl">Time Left</div>
            <div class="auction-card__timer-val${a.endMins<60?' urgent':''}" data-countdown="${a.endMins}" data-auction-id="${a.id}">${SSA.formatTime(a.endMins)}</div>
          </div>
        </div>
        <button class="auction-card__cta" aria-label="View and bid on ${a.name}">View &amp; Bid →</button>
      </div>
    </article>`;
  }

  function toggleWatch(auctionId, btn) {
    const user = SSA.Auth.getSession();
    if (!user) { SSA.toast('Log in to save to watchlist', 'warning'); return; }
    const result = SSA.watchlist.toggle(user.id, auctionId);
    btn.textContent = result.watching ? '❤️' : '🤍';
    btn.classList.toggle('active', result.watching);
    btn.setAttribute('aria-label', (result.watching ? 'Remove from' : 'Add to') + ' watchlist');
    SSA.toast(result.watching ? 'Added to watchlist' : 'Removed from watchlist', result.watching ? 'success' : '');
  }

  function startCountdowns() {
    setInterval(() => {
      document.querySelectorAll('[data-countdown]').forEach(el => {
        const secs = parseInt(el.dataset.countdown) * 60 - Math.floor((Date.now() - parseInt(el.dataset.startTs||Date.now())) / 1000);
        const mins = Math.max(0, Math.floor(secs / 60));
        el.textContent = SSA.formatTime(mins);
        el.classList.toggle('urgent', mins < 60 && mins > 0);
      });
    }, 30000); // Every 30s for demo (production: every second from server timestamp)
  }

  function init(config = {}) {
    const { page='', portal=false } = config;
    injectStyles();
    if (!portal) {
      const user = SSA.Auth.getSession();
      // Inject nav
      const navPlaceholder = document.getElementById('ssa-nav');
      if (navPlaceholder) navPlaceholder.outerHTML = navHTML({ active: page, user });
      // Inject footer
      const footerPlaceholder = document.getElementById('ssa-footer');
      if (footerPlaceholder) footerPlaceholder.outerHTML = footerHTML();
    }
    // Inject bid modal
    if (!document.getElementById('bidModalOverlay')) {
      document.body.insertAdjacentHTML('beforeend', bidModalHTML());
    }
    startCountdowns();
    // Keyboard nav for auction cards
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') closeBidModal();
      if (e.key === 'Enter' && e.target.classList.contains('auction-card')) e.target.click();
    });
  }

  return { init, auctionCardHTML, openBidModal, closeBidModal, updateBidCalc, submitBid, submitAutoBid, toggleWatch, confirm };
})();

window.SSAComponents = SSAComponents;
