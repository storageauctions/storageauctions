/**
 * SSA Platform — Test Mode & Integrations Extension
 * Appended to api.js seed data and settings
 * Include this after api.js on pages that need it,
 * OR merge these additions into api.js directly.
 *
 * This module adds:
 *   - Test mode management
 *   - Integrations key store
 *   - Test event simulation
 *   - Data reset utilities
 */

const SSATest = (function() {
  'use strict';

  const TEST_BANNER_ID = 'ssa-test-banner';

  /* ── INTEGRATIONS SEED ───────────────────────────────────── */
  const INTEGRATIONS_SEED = {
    /* PAYMENT GATEWAYS */
    stripe: {
      id: 'stripe', category: 'payment', name: 'Stripe',
      icon: '💳', status: 'test',
      fields: {
        publishable_key:  { label:'Publishable Key',  type:'text',     test:'pk_test_51xxxxx', help:'Starts with pk_test_ (test) or pk_live_ (live)' },
        secret_key:       { label:'Secret Key',       type:'password', test:'sk_test_51xxxxx', help:'Never expose. Server-side only in production.' },
        webhook_secret:   { label:'Webhook Secret',   type:'password', test:'whsec_xxxxx',     help:'From Stripe → Developers → Webhooks' },
        account_id:       { label:'Connected Account ID', type:'text', test:'',               help:'Only for Stripe Connect multi-operator payouts' },
      }
    },
    square: {
      id: 'square', category: 'payment', name: 'Square',
      icon: '⬛', status: 'inactive',
      fields: {
        app_id:           { label:'Application ID',   type:'text',     test:'sandbox-sq0idb-xxxxx', help:'From Square Developer Dashboard' },
        access_token:     { label:'Access Token',     type:'password', test:'EAAAxxxxx',             help:'Sandbox or production access token' },
        location_id:      { label:'Location ID',      type:'text',     test:'',                     help:'From Square Dashboard → Locations' },
      }
    },
    payto: {
      id: 'payto', category: 'payment', name: 'PayTo (NPP)',
      icon: '🏦', status: 'inactive',
      fields: {
        client_id:        { label:'Client ID',        type:'text',     test:'', help:'From your PayTo-enabled bank or provider (e.g. Monoova, Zepto)' },
        client_secret:    { label:'Client Secret',    type:'password', test:'', help:'Keep secure. Never expose client-side.' },
        bsb:              { label:'Settlement BSB',   type:'text',     test:'', help:'BSB of your receiving bank account' },
        account_number:   { label:'Account Number',   type:'text',     test:'', help:'Settlement account number' },
      }
    },

    /* EMAIL PROVIDERS */
    sendgrid: {
      id: 'sendgrid', category: 'email', name: 'SendGrid',
      icon: '📧', status: 'test',
      fields: {
        api_key:          { label:'API Key',          type:'password', test:'SG.xxxxxx', help:'Create at app.sendgrid.com → Settings → API Keys. Use "Restricted Access" — Mail Send only.' },
        from_email:       { label:'Verified From Email', type:'text', test:'noreply@selfstorageauctions.com.au', help:'Must be verified in SendGrid → Sender Authentication' },
        from_name:        { label:'From Name',        type:'text',     test:'SelfStorageAuctions.com.au', help:'Displayed name in email client' },
        template_prefix:  { label:'Template ID Prefix (optional)', type:'text', test:'', help:'If using SendGrid Dynamic Templates, prefix of template IDs' },
      }
    },
    postmark: {
      id: 'postmark', category: 'email', name: 'Postmark',
      icon: '📮', status: 'inactive',
      fields: {
        server_token:     { label:'Server API Token',  type:'password', test:'', help:'From Postmark → Server → API Tokens. "Transactional" stream.' },
        from_email:       { label:'From Email',        type:'text',     test:'', help:'Must be a verified sender signature in Postmark' },
        message_stream:   { label:'Message Stream ID', type:'text',     test:'outbound', help:'Usually "outbound" for transactional' },
      }
    },
    ses: {
      id: 'ses', category: 'email', name: 'Amazon SES',
      icon: '🌐', status: 'inactive',
      fields: {
        access_key_id:    { label:'AWS Access Key ID',     type:'text',     test:'', help:'IAM user with SES:SendEmail permission only' },
        secret_access_key:{ label:'AWS Secret Access Key', type:'password', test:'', help:'Never expose. Use IAM roles in production.' },
        region:           { label:'AWS Region',            type:'text',     test:'ap-southeast-2', help:'Use ap-southeast-2 (Sydney) for lowest latency' },
        from_email:       { label:'Verified Sender Email', type:'text',     test:'', help:'Verified in SES → Verified identities' },
      }
    },

    /* SMS PROVIDERS */
    twilio: {
      id: 'twilio', category: 'sms', name: 'Twilio',
      icon: '📱', status: 'test',
      fields: {
        account_sid:      { label:'Account SID',      type:'text',     test:'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', help:'From console.twilio.com → Account Info' },
        auth_token:       { label:'Auth Token',       type:'password', test:'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',   help:'Keep secret. Rotate if exposed.' },
        sender_id:        { label:'Sender ID / Number', type:'text',   test:'SSAuctions', help:'Max 11 chars for alphanumeric. Must register with ACMA for AU sender IDs.' },
        messaging_service_sid: { label:'Messaging Service SID (optional)', type:'text', test:'', help:'For multi-number sending and compliance' },
      }
    },
    messagebird: {
      id: 'messagebird', category: 'sms', name: 'MessageBird',
      icon: '🐦', status: 'inactive',
      fields: {
        api_key:          { label:'API Key',          type:'password', test:'', help:'From dashboard.messagebird.com → Developers → API access keys' },
        originator:       { label:'Originator',       type:'text',     test:'SSAuctions', help:'Alphanumeric sender ID or phone number' },
      }
    },

    /* AI */
    anthropic: {
      id: 'anthropic', category: 'ai', name: 'Anthropic (Claude)',
      icon: '🤖', status: 'active',
      fields: {
        api_key:          { label:'API Key',          type:'password', test:'sk-ant-xxxxxx', help:'From console.anthropic.com → API Keys. The AI description generator uses claude-sonnet-4-20250514.' },
        model:            { label:'Model',            type:'text',     test:'claude-sonnet-4-20250514', help:'Recommended: claude-sonnet-4-20250514 (fast + high quality). Upgrade to claude-opus-4-20250514 for premium.' },
        max_tokens:       { label:'Max Tokens',       type:'text',     test:'500',  help:'Max tokens for description generation. 500 is sufficient.' },
      }
    },

    /* IMAGE STORAGE */
    cloudinary: {
      id: 'cloudinary', category: 'storage', name: 'Cloudinary',
      icon: '🖼️', status: 'inactive',
      fields: {
        cloud_name:       { label:'Cloud Name',       type:'text',     test:'', help:'From cloudinary.com → Dashboard. Used in image upload URLs.' },
        api_key:          { label:'API Key',          type:'text',     test:'', help:'From Settings → Access Keys' },
        api_secret:       { label:'API Secret',       type:'password', test:'', help:'Keep secret. Used for server-side signed uploads.' },
        upload_preset:    { label:'Upload Preset',    type:'text',     test:'ssa_unsigned', help:'Create unsigned upload preset in Cloudinary settings for client-side uploads' },
      }
    },
    s3: {
      id: 's3', category: 'storage', name: 'Amazon S3',
      icon: '🪣', status: 'inactive',
      fields: {
        bucket_name:      { label:'Bucket Name',      type:'text',     test:'ssa-auction-photos', help:'Create in S3 console. Enable public read for photo display.' },
        access_key_id:    { label:'AWS Access Key ID', type:'text',    test:'', help:'IAM user with S3:PutObject and S3:GetObject on this bucket only' },
        secret_access_key:{ label:'Secret Access Key', type:'password', test:'', help:'Rotate regularly. Consider IAM roles in production.' },
        region:           { label:'Region',           type:'text',     test:'ap-southeast-2', help:'ap-southeast-2 (Sydney) recommended' },
        cdn_url:          { label:'CloudFront URL (optional)', type:'text', test:'', help:'CDN URL prefix for fast image delivery. Format: https://xxxxx.cloudfront.net' },
      }
    },

    /* DATABASE (Phase 2) */
    supabase: {
      id: 'supabase', category: 'database', name: 'Supabase',
      icon: '🗄️', status: 'phase2',
      fields: {
        project_url:      { label:'Project URL',      type:'text',     test:'https://xxxxx.supabase.co', help:'From supabase.com → Project → Settings → API. Swap api.js to Supabase adapter in Phase 2.' },
        anon_key:         { label:'Anon (Public) Key', type:'text',    test:'eyJxxxxxxx', help:'Safe to expose client-side. Enforces Row Level Security.' },
        service_role_key: { label:'Service Role Key', type:'password', test:'', help:'NEVER expose client-side. Server-side only (Netlify Functions). Bypasses RLS.' },
        db_password:      { label:'Database Password', type:'password', test:'', help:'Direct database connection. Required for migrations.' },
      }
    },

    /* ANALYTICS */
    ga4: {
      id: 'ga4', category: 'analytics', name: 'Google Analytics 4',
      icon: '📊', status: 'inactive',
      fields: {
        measurement_id:   { label:'Measurement ID',   type:'text',     test:'G-XXXXXXXXXX', help:'From GA4 → Admin → Data Streams → Web stream details' },
        api_secret:       { label:'Measurement Protocol API Secret (optional)', type:'password', test:'', help:'For server-side event tracking' },
      }
    },
    plausible: {
      id: 'plausible', category: 'analytics', name: 'Plausible Analytics',
      icon: '📈', status: 'inactive',
      fields: {
        domain:           { label:'Domain',           type:'text',     test:'selfstorageauctions.com.au', help:'Your site domain as registered in Plausible. Privacy-focused GA alternative.' },
      }
    },

    /* MONITORING */
    sentry: {
      id: 'sentry', category: 'monitoring', name: 'Sentry (Error Tracking)',
      icon: '🐛', status: 'inactive',
      fields: {
        dsn:              { label:'DSN',              type:'text',     test:'', help:'From sentry.io → Project → Settings → Client Keys (DSN). Automatically captures JS errors.' },
        environment:      { label:'Environment',      type:'text',     test:'production', help:'e.g. production, staging, development' },
      }
    },

    /* DOMAIN & CDN */
    netlify: {
      id: 'netlify', category: 'infrastructure', name: 'Netlify',
      icon: '🚀', status: 'active',
      fields: {
        site_id:          { label:'Site ID',          type:'text',     test:'', help:'From Netlify → Site → Site Configuration → Site ID' },
        auth_token:       { label:'Personal Access Token', type:'password', test:'', help:'For CI/CD deployments via CLI. Netlify → User Settings → Applications → Personal access tokens' },
        custom_domain:    { label:'Custom Domain',    type:'text',     test:'selfstorageauctions.com.au', help:'Add in Netlify → Domain Management. Point DNS A record to Netlify.' },
      }
    },

    /* NOTIFICATIONS (Phase 2) */
    onesignal: {
      id: 'onesignal', category: 'push', name: 'OneSignal (Push Notifications)',
      icon: '🔔', status: 'inactive',
      fields: {
        app_id:           { label:'App ID',           type:'text',     test:'', help:'From OneSignal → Settings → Keys & IDs. Enables browser push notifications.' },
        rest_api_key:     { label:'REST API Key',     type:'password', test:'', help:'Server-side use for sending pushes. Keep secret.' },
      }
    },

    /* IDENTITY VERIFICATION (Phase 3) */
    stripe_identity: {
      id: 'stripe_identity', category: 'verification', name: 'Stripe Identity',
      icon: '🪪', status: 'phase3',
      fields: {
        note:             { label:'Note',             type:'text',     test:'Uses existing Stripe keys', help:'Stripe Identity is an add-on to your Stripe account. Enable in Stripe Dashboard → Identity → Get started.' },
      }
    },
  };

  /* ── TEST MODE ────────────────────────────────────────────── */
  function isTestMode() {
    return localStorage.getItem('ssa_test_mode') === 'true';
  }

  function setTestMode(val) {
    localStorage.setItem('ssa_test_mode', String(val));
    if (val) showTestBanner();
    else hideTestBanner();
  }

  function showTestBanner() {
    if (document.getElementById(TEST_BANNER_ID)) return;
    const banner = document.createElement('div');
    banner.id = TEST_BANNER_ID;
    banner.innerHTML = `
      <div style="background:#D97706;color:#fff;padding:8px 20px;text-align:center;font-size:.82rem;font-weight:700;display:flex;align-items:center;justify-content:center;gap:12px;position:sticky;top:0;z-index:600">
        <span>🧪</span>
        <span>TEST MODE ACTIVE — Payments, emails and SMS are simulated. No real charges or messages.</span>
        <button onclick="SSATest.setTestMode(false);location.reload()" style="background:rgba(255,255,255,.25);border:none;color:#fff;padding:3px 12px;border-radius:4px;font-size:.78rem;font-weight:700;cursor:pointer;margin-left:8px">Exit Test Mode</button>
      </div>`;
    document.body.insertBefore(banner, document.body.firstChild);
  }

  function hideTestBanner() {
    document.getElementById(TEST_BANNER_ID)?.remove();
  }

  function injectTestBannerIfActive() {
    if (isTestMode()) showTestBanner();
  }

  /* ── TEST EVENTS ─────────────────────────────────────────── */
  const testEvents = {
    simulateOutbid(auctionId) {
      const a = SSA.auctions.get(auctionId || SSA.auctions.list()[0]?.id);
      if (!a) return;
      SSA.auctions.bid(a.id, 'B_TEST', a.bid + 10);
      SSA.toast(`🧪 TEST: Outbid notification fired for ${a.name.substring(0,30)}…`, 'warning');
    },
    simulateWin(auctionId) {
      const auction = SSA.auctions.get(auctionId || SSA.auctions.list()[0]?.id);
      if (!auction) return;
      const calc = SSA.auctions.calculateTotal(auction.bid);
      SSA.toast(`🧪 TEST: Win notification fired — Total: ${SSA.formatCurrency(calc.total)}`, 'success');
    },
    simulatePayment(auctionId) {
      SSA.toast('🧪 TEST: Payment processed via Stripe test mode. Receipt generated.', 'success');
    },
    simulateNonPayment(auctionId) {
      SSA.toast('🧪 TEST: Non-payment escalation triggered — 24hr reminder email fired', 'warning');
    },
    simulateNewAuction() {
      const states = ['NSW','VIC','QLD','WA','SA'];
      const emojis = ['📦','🛋️','🔧','📚','🎸','💼'];
      const newAuction = {
        facilityId: 'F001', facility: 'Test Facility', state: states[Math.floor(Math.random()*states.length)],
        suburb: 'Test Suburb', emoji: emojis[Math.floor(Math.random()*emojis.length)],
        name: `TEST Unit ${Math.floor(Math.random()*99)}A — Dummy Auction for Testing`,
        bid: Math.floor(Math.random()*200)+50, startBid: 50, reserve: 0, bids: 0, watchers: 0,
        endMins: 4320, featured: false, status: 'live', deposit: 0,
        description: 'This is a test auction generated by Test Mode. It does not represent a real unit.',
        photos: [], pickup: 'Test pickup instructions', viewable: false
      };
      SSA.auctions.create(newAuction);
      SSA.toast('🧪 TEST: New auction created — alert emails would fire to matching subscribers', 'success');
    },
    resetToSeedData() {
      const keys = Object.keys(localStorage).filter(k => k.startsWith('ssa_'));
      keys.forEach(k => localStorage.removeItem(k));
      SSA.toast('🧪 Platform reset to seed data. Reloading…', 'warning');
      setTimeout(() => location.reload(), 1200);
    }
  };

  /* ── INTEGRATIONS STORE ──────────────────────────────────── */
  const integrations = {
    getAll() {
      try { return JSON.parse(localStorage.getItem('ssa_integrations') || '{}'); } catch { return {}; }
    },
    get(serviceId) {
      return this.getAll()[serviceId] || {};
    },
    save(serviceId, values) {
      const all = this.getAll();
      all[serviceId] = { ...all[serviceId], ...values, updatedAt: new Date().toISOString() };
      localStorage.setItem('ssa_integrations', JSON.stringify(all));
      SSA.audit.log('integration_update', serviceId, `Integration updated: ${serviceId}`);
      return { ok: true };
    },
    getStatus(serviceId) {
      const saved = this.get(serviceId);
      const seed = INTEGRATIONS_SEED[serviceId];
      if (!seed) return 'unknown';
      if (seed.status === 'phase2' || seed.status === 'phase3') return seed.status;
      const hasValues = Object.keys(seed.fields || {}).some(k => saved[k] && saved[k].length > 0 && !saved[k].includes('xxxxx'));
      if (hasValues) return 'connected';
      const hasTest = Object.keys(seed.fields || {}).some(k => saved[k]?.includes('xxxxx') || seed.fields[k]?.test?.includes('xxxxx'));
      if (hasTest || seed.status === 'test') return 'test';
      return 'inactive';
    },
    SEED: INTEGRATIONS_SEED,
    categories: {
      payment: 'Payment Gateways',
      email: 'Email Providers',
      sms: 'SMS Providers',
      ai: 'AI Services',
      storage: 'Image & File Storage',
      database: 'Database (Phase 2)',
      analytics: 'Analytics',
      monitoring: 'Error Monitoring',
      infrastructure: 'Infrastructure & CDN',
      push: 'Push Notifications',
      verification: 'Identity Verification (Phase 3)',
    }
  };

  // Init: show banner if test mode on page load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectTestBannerIfActive);
  } else {
    injectTestBannerIfActive();
  }

  return { isTestMode, setTestMode, testEvents, integrations, INTEGRATIONS_SEED };
})();

window.SSATest = SSATest;
