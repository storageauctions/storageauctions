/**
 * SSA Platform — API Abstraction Layer
 * =====================================
 * ALL data operations go through this file.
 * To swap backend (localStorage → Supabase → custom API),
 * change ONLY this file. All UI code remains identical.
 *
 * Current adapter: localStorage (Phase 1 / Demo)
 * Next adapter: Supabase (Phase 2)
 */

const API = (function() {
  'use strict';

  /* ── ADAPTER SELECTOR ─────────────────────────────────────────
     Change 'localStorage' to 'supabase' when Phase 2 is ready.
     All methods below proxy to the selected adapter.
  ─────────────────────────────────────────────────────────────── */
  const ADAPTER = 'localStorage'; // 'localStorage' | 'supabase' | 'rest'

  /* ── SEED DATA ─────────────────────────────────────────────── */
  const SEED = {
    settings: {
      buyer_premium_pct: 10,
      operator_monthly_fee: 99,
      gst_rate: 10,
      gst_inclusive: true,
      gst_mode: 'inclusive',        // 'inclusive' | 'exclusive' | 'none'
      payment_provider: 'stripe',   // 'stripe' | 'square' | 'payto' | 'pin'
      payment_test_mode: true,
      soft_close_minutes: 2,
      payment_window_hours: 24,
      collection_window_hours: 72,
      nonpayment_strike_limit: 3,
      second_chance_offer: true,
      auto_relist_on_nonpayment: true,
      max_photos_per_auction: 10,
      featured_auction_slots: 4,
      min_bid_increments: [
        { from: 0, to: 50, increment: 2 },
        { from: 50, to: 200, increment: 5 },
        { from: 200, to: 1000, increment: 10 },
        { from: 1000, to: 5000, increment: 25 },
        { from: 5000, to: Infinity, increment: 50 }
      ],
      email_provider: 'sendgrid',   // 'sendgrid' | 'postmark' | 'ses'
      email_from_name: 'SelfStorageAuctions.com.au',
      email_from_address: 'noreply@selfstorageauctions.com.au',
      sms_provider: 'twilio',       // 'twilio' | 'messagebird'
      sms_enabled: true,
      sms_sender_id: 'SSAuctions',
      platform_name: 'SelfStorageAuctions.com.au',
      platform_url: 'https://www.selfstorageauctions.com.au',
      support_email: 'support@selfstorageauctions.com.au',
      abn: 'XX XXX XXX XXX',
      // Phase 2: API keys stored encrypted server-side, never in client
    },
    content: {
      homepage: {
        hero_headline: 'Win Big. Bid on <em>Abandoned</em> Storage Units.',
        hero_sub: 'Browse units listed by facilities across Australia. Search by suburb, state or brand. Fair, transparent auctions at Australia\'s lowest buyer\'s premium.',
        hero_tagline: 'Hunt, find, bid & score — all from your couch.',
        hero_label: 'Australia\'s New Storage Auction Platform',
        stat_premium: '10%',
        stat_premium_label: 'Buyer\'s Premium',
        stat_premium_note: 'vs 17.5% elsewhere',
        stat_facilities: '280+',
        stat_facilities_label: 'Storage Facilities',
        stat_registration: '$0',
        stat_registration_label: 'Buyer Registration',
        cta_primary_text: 'Browse Live Auctions',
        cta_primary_href: '/auctions/',
        cta_secondary_text: 'Register Free',
        cta_secondary_href: '/buyer/',
      },
      global: {
        tagline: 'Hunt. Find. Bid. Score.',
        operator_tagline: 'List Once. Recover Fast.',
        footer_desc: 'Australia\'s modern, transparent self storage auction platform — built for operators who want results and buyers who want bargains.',
        ssl_badge: 'SSL Secured · Australian Owned & Operated',
      }
    },
    emailTemplates: {
      buyer_welcome: {
        id: 'buyer_welcome',
        name: 'Buyer Welcome',
        subject: 'Welcome to SelfStorageAuctions.com.au, {{first_name}}!',
        trigger: 'On buyer registration',
        category: 'buyer',
        body: `Hi {{first_name}},\n\nWelcome to SelfStorageAuctions.com.au!\n\nYour account is set up and ready. Here's what you can do right now:\n\n• Browse live auctions at {{platform_url}}/auctions/\n• Set up auction alerts for your preferred areas\n• Configure auto-bid to never miss a unit\n\nRemember: our buyer's premium is just 10% — the lowest in Australia.\n\nHunt. Find. Bid. Score.\n\nThe SSA Team\n{{platform_name}}`
      },
      buyer_outbid: {
        id: 'buyer_outbid',
        name: 'Outbid Alert',
        subject: 'You\'ve been outbid on {{auction_name}}',
        trigger: 'When buyer is outbid',
        category: 'buyer',
        body: `Hi {{first_name}},\n\nYou've been outbid!\n\nAuction: {{auction_name}}\nFacility: {{facility_name}}, {{state}}\nNew highest bid: ${{current_bid}}\nTime remaining: {{time_remaining}}\n\nBid now: {{auction_url}}\n\nTip: Set an auto-bid maximum so you never miss out while you're away.\n\n{{platform_name}}`
      },
      buyer_win: {
        id: 'buyer_win',
        name: 'Win Notification',
        subject: '🎉 You won! {{auction_name}} — Payment due now',
        trigger: 'When auction closes and buyer wins',
        category: 'buyer',
        body: `Hi {{first_name}},\n\nCongratulations! You've won the auction.\n\nAuction: {{auction_name}}\nFacility: {{facility_name}}, {{state}}\nWinning bid: ${{winning_bid}}\nBuyer's premium ({{premium_pct}}%): ${{premium_amount}}\nTotal payable: ${{total_amount}} ({{gst_note}})\n\nPay now (link expires in {{payment_window_hours}} hours):\n{{payment_url}}\n\nCollection window: {{collection_window_hours}} hours after payment\nFacility address: {{facility_address}}\nFacility contact: {{facility_phone}}\n\nPlease bring:\n• Photo ID\n• Payment confirmation\n• Your own transport\n\n{{platform_name}}`
      },
      buyer_payment_confirmed: {
        id: 'buyer_payment_confirmed',
        name: 'Payment Confirmed',
        subject: 'Payment confirmed — Collect your unit',
        trigger: 'When payment is successfully processed',
        category: 'buyer',
        body: `Hi {{first_name}},\n\nYour payment of ${{total_amount}} has been received.\n\nAuction: {{auction_name}}\nFacility: {{facility_name}}\nAddress: {{facility_address}}\n\nCollection window: By {{collection_deadline}}\nFacility hours: {{facility_hours}}\nFacility phone: {{facility_phone}}\n\nPresent this email at the facility. Collection reference: {{collection_ref}}\n\nAll contents must be removed and the unit left broom-clean within your collection window.\n\n{{platform_name}}`
      },
      operator_approved: {
        id: 'operator_approved',
        name: 'Facility Approved',
        subject: 'Your facility has been approved — you\'re ready to list!',
        trigger: 'When superadmin approves a facility',
        category: 'operator',
        body: `Hi {{contact_name}},\n\nGreat news — {{facility_name}} has been approved on SelfStorageAuctions.com.au!\n\nYou can now:\n• Create your first auction listing\n• Set up your facility profile\n• Access your operator dashboard\n\nLogin: {{platform_url}}/operator/\n\nYour first 30 days are free. Subscription (${{operator_fee}}/month) starts on {{trial_end_date}}.\n\nNeed help getting started? Email {{support_email}} or call your account manager.\n\n{{platform_name}}`
      },
      operator_auction_closed: {
        id: 'operator_auction_closed',
        name: 'Auction Closed',
        subject: 'Auction closed: {{auction_name}} — ${{winning_bid}} winning bid',
        trigger: 'When an operator\'s auction closes',
        category: 'operator',
        body: `Hi {{contact_name}},\n\nYour auction has closed.\n\nUnit: {{auction_name}}\nClosing bid: ${{winning_bid}}\nBuyer: Buyer ID {{buyer_ref}} (details withheld for privacy)\nPayment due by: {{payment_deadline}}\n\nWe'll notify you when payment is received. Your payout (${{operator_payout}}) will be processed within {{payout_days}} business days of payment confirmation.\n\nAudit PDF: Available in your operator dashboard.\n\n{{platform_name}}`
      }
    },
    smsTemplates: {
      buyer_outbid: {
        id: 'sms_buyer_outbid',
        name: 'Outbid Alert (SMS)',
        trigger: 'When buyer is outbid',
        body: 'SSAuctions: You\'ve been outbid on {{auction_short_name}}. Current bid: ${{current_bid}}. {{time_remaining}} left. Bid: {{short_url}} Reply STOP to opt out.'
      },
      buyer_win: {
        id: 'sms_buyer_win',
        name: 'Win Notification (SMS)',
        trigger: 'When buyer wins',
        body: 'SSAuctions: 🎉 You won {{auction_short_name}}! Total: ${{total_amount}}. Pay now ({{payment_window_hours}}hr window): {{short_url}} Reply STOP to opt out.'
      },
      buyer_payment_confirmed: {
        id: 'sms_buyer_payment_confirmed',
        name: 'Payment Confirmed (SMS)',
        trigger: 'When payment confirmed',
        body: 'SSAuctions: Payment received. Collect your unit at {{facility_name}} by {{collection_deadline}}. Ref: {{collection_ref}} Reply STOP to opt out.'
      }
    },
    auctions: [
      { id:'A001', facilityId:'F001', facility:'Kennards Self Storage', state:'NSW', suburb:'Parramatta', emoji:'📦', name:'Unit 4B — Household Goods, Furniture & Personal Items', bid:185, startBid:50, reserve:100, bids:12, watchers:23, endMins:134, featured:true, status:'live', description:'Mixed household items including bedroom furniture, clothing, boxes of personal items and kitchenware. Unit appears to contain some quality pieces visible at front.', photos:[], pickup:'Winner has 72 hours to collect. Photo ID required.', viewable:false, deposit:200, created:'2025-03-01' },
      { id:'A002', facilityId:'F002', facility:'Storage King', state:'VIC', suburb:'Moorabbin', emoji:'🛋️', name:'Unit 12A — Furniture, White Goods & Power Tools', bid:340, startBid:100, reserve:200, bids:27, watchers:41, endMins:38, featured:true, status:'live', description:'Large unit containing lounge suite, refrigerator, washing machine, assorted power tools and garden equipment.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:true, deposit:200, created:'2025-03-05' },
      { id:'A003', facilityId:'F003', facility:'National Storage', state:'QLD', suburb:'Fortitude Valley', emoji:'🎸', name:'Unit 7C — Electronics, Musical Instruments & Collectibles', bid:520, startBid:200, reserve:300, bids:3, watchers:67, endMins:4686, featured:true, status:'live', description:'Compact but densely packed unit with electronics, what appears to be guitar equipment, and several labelled collectible boxes.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:false, deposit:200, created:'2025-03-08' },
      { id:'A004', facilityId:'F004', facility:'Fort Knox Storage', state:'WA', suburb:'Osborne Park', emoji:'🔧', name:'Unit 3D — Workshop Tools, Garden & Camping Equipment', bid:110, startBid:50, reserve:75, bids:9, watchers:14, endMins:1680, featured:false, status:'live', description:'Full workshop setup including hand tools, power tools, garden equipment and camping gear.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:true, deposit:200, created:'2025-03-10' },
      { id:'A005', facilityId:'F001', facility:'Kennards Self Storage', state:'NSW', suburb:'Artarmon', emoji:'👗', name:'Unit 9E — Fashion, Clothing & Retail Overstock', bid:75, startBid:25, reserve:0, bids:5, watchers:19, endMins:352, featured:false, status:'live', description:'Large selection of clothing, accessories and what appears to be retail overstock including sealed boxes.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:false, deposit:0, created:'2025-03-12' },
      { id:'A006', facilityId:'F005', facility:'Casey Self Storage', state:'SA', suburb:'Glenelg', emoji:'📚', name:'Unit 2A — Books, Office Equipment & Filing', bid:25, startBid:10, reserve:0, bids:1, watchers:7, endMins:6511, featured:false, status:'live', description:'Rows of boxed books, office furniture, filing cabinets and computer equipment.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:false, deposit:0, created:'2025-03-13' },
      { id:'A007', facilityId:'F001', facility:'Kennards Self Storage', state:'NSW', suburb:'Rouse Hill', emoji:'🏠', name:'Unit 6F — Moving Unit — Full House Contents', bid:890, startBid:500, reserve:600, bids:19, watchers:88, endMins:720, featured:true, status:'live', description:'Premium unit packed to the ceiling with quality furniture, artwork, kitchen equipment and personal items.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:true, deposit:500, created:'2025-03-02' },
      { id:'A008', facilityId:'F003', facility:'National Storage', state:'QLD', suburb:'Newstead', emoji:'💼', name:'Unit 1C — Business Equipment & Office Fit-Out', bid:240, startBid:100, reserve:150, bids:8, watchers:31, endMins:2160, featured:false, status:'live', description:'Office desks, chairs, computers, server rack components, filing systems and business equipment.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:false, deposit:200, created:'2025-03-07' },
      { id:'A009', facilityId:'F002', facility:'Storage King', state:'NSW', suburb:'Penrith', emoji:'🚲', name:'Unit 8B — Sports, Bikes & Outdoor Equipment', bid:155, startBid:50, reserve:100, bids:14, watchers:26, endMins:95, featured:false, status:'ending', description:'Multiple bicycles, gym equipment, kayak, surfboards and extensive sporting goods.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:false, deposit:200, created:'2025-03-09' },
      { id:'A010', facilityId:'F004', facility:'Fort Knox Storage', state:'VIC', suburb:'Dandenong', emoji:'🎨', name:'Unit 11D — Art, Antiques & Vintage Items', bid:610, startBid:200, reserve:400, bids:22, watchers:104, endMins:510, featured:false, status:'live', description:'Carefully packed unit containing framed artworks, ornamental pieces, vintage furniture and several clearly labelled antique boxes.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:true, deposit:200, created:'2025-03-04' },
      { id:'A011', facilityId:'F005', facility:'Casey Self Storage', state:'QLD', suburb:'Loganholme', emoji:'🍳', name:'Unit 5A — Kitchen & Homewares', bid:45, startBid:20, reserve:0, bids:4, watchers:11, endMins:3024, featured:false, status:'new', description:'Kitchen appliances, cookware, crockery sets, small appliances and homewares.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:false, deposit:0, created:'2025-03-14' },
      { id:'A012', facilityId:'F006', facility:'Wilson Storage', state:'WA', suburb:'Balcatta', emoji:'📷', name:'Unit 14C — Photography & Creative Studio Equipment', bid:730, startBid:300, reserve:500, bids:16, watchers:92, endMins:1440, featured:false, status:'live', description:'Professional photography equipment, lighting rigs, backdrops, lenses and creative studio accessories.', photos:[], pickup:'Winner has 72 hours to collect.', viewable:false, deposit:200, created:'2025-03-06' },
    ],
    facilities: [
      { id:'F001', name:'Kennards Self Storage', contact:'K. Storage Pty Ltd', email:'ops@kennards.com.au', phone:'02 9000 0000', state:'NSW', suburb:'Parramatta', address:'1 Storage St, Parramatta NSW 2150', status:'approved', plan:'standard', joined:'2025-01-15', abn:'11 111 111 111' },
      { id:'F002', name:'Storage King', contact:'SK Operations', email:'ops@storageking.com.au', phone:'03 9000 0000', state:'VIC', suburb:'Moorabbin', address:'2 Warehouse Dr, Moorabbin VIC 3189', status:'approved', plan:'standard', joined:'2025-02-01', abn:'22 222 222 222' },
      { id:'F003', name:'National Storage', contact:'NS Group', email:'ops@nationalstorage.com.au', phone:'07 9000 0000', state:'QLD', suburb:'Fortitude Valley', address:'3 Unit Way, Fortitude Valley QLD 4006', status:'approved', plan:'standard', joined:'2025-02-15', abn:'33 333 333 333' },
      { id:'F004', name:'Fort Knox Storage', contact:'Fort Knox', email:'ops@fortknox.com.au', phone:'08 9000 0000', state:'WA', suburb:'Osborne Park', address:'4 Lock Rd, Osborne Park WA 6017', status:'approved', plan:'standard', joined:'2025-02-20', abn:'44 444 444 444' },
      { id:'F005', name:'Casey Self Storage', contact:'Casey Group', email:'ops@casey.com.au', phone:'08 8000 0000', state:'SA', suburb:'Glenelg', address:'5 Bay Rd, Glenelg SA 5045', status:'approved', plan:'standard', joined:'2025-03-01', abn:'55 555 555 555' },
      { id:'F006', name:'Wilson Storage', contact:'Wilson', email:'ops@wilson.com.au', phone:'08 9100 0000', state:'WA', suburb:'Balcatta', address:'6 Depot St, Balcatta WA 6021', status:'approved', plan:'standard', joined:'2025-03-05', abn:'66 666 666 666' },
      { id:'F007', name:'StowHub — Rouse Hill', contact:'James T.', email:'james@stowhub.com.au', phone:'02 8888 0000', state:'NSW', suburb:'Rouse Hill', address:'7 Hub Rd, Rouse Hill NSW 2155', status:'pending', plan:'standard', joined:'2025-03-14', abn:'77 777 777 777' },
      { id:'F008', name:'BlueBox Storage', contact:'Sarah M.', email:'sarah@bluebox.com.au', phone:'07 7777 0000', state:'QLD', suburb:'Sunshine Coast', address:'8 Blue St, Mooloolaba QLD 4557', status:'pending', plan:'standard', joined:'2025-03-13', abn:'88 888 888 888' },
    ],
    users: {
      buyers: [
        { id:'B001', name:'David Miller', email:'david@email.com', mobile:'0411 111 111', state:'NSW', joined:'2025-02-01', status:'active', strikes:0, verified:true, bids:8, wins:2, totalSpent:425 },
        { id:'B002', name:'Sarah Connor', email:'sarah@email.com', mobile:'0422 222 222', state:'VIC', joined:'2025-02-15', status:'active', strikes:0, verified:true, bids:12, wins:3, totalSpent:680 },
        { id:'B003', name:'Tim Robertson', email:'tim@email.com', mobile:'0433 333 333', state:'QLD', joined:'2025-03-01', status:'active', strikes:1, verified:false, bids:5, wins:1, totalSpent:220 },
        { id:'B004', name:'Karen Wu', email:'karen@email.com', mobile:'0444 444 444', state:'WA', joined:'2025-03-05', status:'suspended', strikes:3, verified:true, bids:3, wins:0, totalSpent:0, suspendedUntil:'2025-04-05', suspendReason:'Non-payment x3' },
        { id:'B005', name:'Demo Buyer', email:'demo@email.com', mobile:'0400 000 000', state:'NSW', joined:'2025-03-14', status:'active', strikes:0, verified:false, bids:0, wins:0, totalSpent:0 },
      ],
      operators: []
    },
    auditLog: [
      { id:'L001', ts:'2025-03-14T09:22:11Z', admin:'admin@ssa.com.au', action:'approve_facility', target:'F006', details:'Approved Wilson Storage — Balcatta WA', ip:'203.0.113.1' },
      { id:'L002', ts:'2025-03-13T14:05:33Z', admin:'admin@ssa.com.au', action:'suspend_user', target:'B004', details:'Suspended Karen Wu until 2025-04-05 — Non-payment x3', ip:'203.0.113.1' },
      { id:'L003', ts:'2025-03-12T11:44:22Z', admin:'admin@ssa.com.au', action:'update_setting', target:'buyer_premium_pct', details:'Changed from 12 to 10', ip:'203.0.113.1' },
      { id:'L004', ts:'2025-03-10T08:30:00Z', admin:'admin@ssa.com.au', action:'feature_auction', target:'A007', details:'Marked Unit 6F as featured', ip:'203.0.113.1' },
    ]
  };

  /* ── LOCAL STORAGE ADAPTER ─────────────────────────────────── */
  const LocalAdapter = {
    _prefix: 'ssa_',
    _get(key) {
      try { return JSON.parse(localStorage.getItem(this._prefix + key)); } catch { return null; }
    },
    _set(key, val) {
      localStorage.setItem(this._prefix + key, JSON.stringify(val));
    },
    _seed() {
      if (!this._get('seeded')) {
        this._set('settings', SEED.settings);
        this._set('content', SEED.content);
        this._set('auctions', SEED.auctions);
        this._set('facilities', SEED.facilities);
        this._set('users', SEED.users);
        this._set('emailTemplates', SEED.emailTemplates);
        this._set('smsTemplates', SEED.smsTemplates);
        this._set('auditLog', SEED.auditLog);
        this._set('seeded', true);
      }
    }
  };

  /* ── AUTH MODULE ───────────────────────────────────────────── */
  const Auth = {
    _sessions: {}, // In production: HTTP-only cookies + server validation

    register(role, data) {
      const la = LocalAdapter;
      const users = la._get('users') || { buyers:[], operators:[] };
      const id = role==='buyer' ? 'B'+(Date.now()) : 'O'+(Date.now());
      const user = {
        id, ...data, role, status:'active', strikes:0, verified:false,
        joined: new Date().toISOString(), bids:0, wins:0, totalSpent:0
      };
      if (role==='buyer') users.buyers.push(user);
      else users.operators.push(user);
      la._set('users', users);
      this._createSession(user);
      return { ok:true, user };
    },

    login(email, password, role) {
      // In production: verify password hash server-side
      const la = LocalAdapter;
      const users = la._get('users') || { buyers:[], operators:[] };
      const allUsers = [...users.buyers, ...(users.operators||[])];
      const user = allUsers.find(u => u.email === email);
      if (!user) {
        this._logFailedAttempt(email);
        return { ok:false, error:'Invalid email or password' };
      }
      if (user.status==='blocked') return { ok:false, error:'This account has been permanently blocked. Contact support.' };
      if (user.status==='suspended') return { ok:false, error:`Account suspended until ${new Date(user.suspendedUntil).toLocaleDateString('en-AU')}. Reason: ${user.suspendReason}` };
      this._createSession(user);
      return { ok:true, user };
    },

    adminLogin(email, password) {
      // In production: strict rate limiting, MFA required, separate auth service
      if (email && password) { // Demo: any credentials
        const admin = { id:'ADMIN', email, role:'superadmin', name:'Super Admin' };
        this._createSession(admin);
        this._auditLog('admin_login', 'ADMIN', 'Admin logged in from browser');
        return { ok:true, user:admin };
      }
      return { ok:false, error:'Invalid credentials' };
    },

    _createSession(user) {
      // In production: JWT stored in HTTP-only cookie via server
      LocalAdapter._set('session', { user, ts: Date.now(), expires: Date.now() + 7*24*60*60*1000 });
    },

    getSession() {
      const session = LocalAdapter._get('session');
      if (!session) return null;
      if (Date.now() > session.expires) { this.logout(); return null; }
      return session.user;
    },

    requireRole(role) {
      const user = this.getSession();
      if (!user) { window.location.href = role==='admin' ? '/admin/' : role==='operator' ? '/operator/' : '/buyer/'; return null; }
      if (user.role !== role) { this.logout(); return null; }
      return user;
    },

    logout() {
      LocalAdapter._set('session', null);
    },

    _failedAttempts: {},
    _logFailedAttempt(email) {
      const key = `attempts_${email}`;
      const attempts = (LocalAdapter._get(key) || 0) + 1;
      LocalAdapter._set(key, attempts);
      if (attempts >= 5) {
        console.warn(`[SECURITY] Account lockout triggered for ${email}`);
        // In production: server-side lockout + notify admin
      }
    },

    _auditLog(action, target, details) {
      const log = LocalAdapter._get('auditLog') || [];
      log.unshift({ id: 'L'+Date.now(), ts: new Date().toISOString(), admin: Auth.getSession()?.email || 'system', action, target, details, ip: '127.0.0.1' });
      LocalAdapter._set('auditLog', log.slice(0, 500)); // Keep last 500 entries
    }
  };

  /* ── AUCTION ENGINE ────────────────────────────────────────── */
  const AuctionEngine = {
    getIncrement(currentBid) {
      const settings = LocalAdapter._get('settings') || SEED.settings;
      const table = settings.min_bid_increments;
      const tier = table.find(t => currentBid >= t.from && currentBid < t.to);
      return tier ? tier.increment : 50;
    },

    placeBid(auctionId, userId, amount) {
      const auctions = LocalAdapter._get('auctions') || [];
      const auction = auctions.find(a => a.id === auctionId);
      if (!auction) return { ok:false, error:'Auction not found' };
      if (auction.status !== 'live' && auction.status !== 'ending') return { ok:false, error:'This auction is not currently accepting bids' };
      const minBid = auction.bid + this.getIncrement(auction.bid);
      if (amount < minBid) return { ok:false, error:`Minimum bid is $${minBid.toFixed(2)}` };

      // Check shill bidding (in production: also check IP + device fingerprint)
      if (auction.facilityId && userId && auction.facilityId === userId) {
        Auth._auditLog('shill_bid_attempt', auctionId, `User ${userId} attempted to bid on own facility auction`);
        return { ok:false, error:'You cannot bid on this auction' };
      }

      auction.bid = amount;
      auction.bids++;
      auction.lastBidder = userId;

      // Soft-close extension
      const settings = LocalAdapter._get('settings') || SEED.settings;
      if (auction.endMins < settings.soft_close_minutes) {
        auction.endMins = settings.soft_close_minutes;
        auction.extended = true;
      }

      // Process auto-bids (simplified — in production: server-side)
      this._processAutoBids(auctions, auction, userId, amount);

      LocalAdapter._set('auctions', auctions);
      Auth._auditLog('bid_placed', auctionId, `Bid of $${amount} placed by ${userId}`);
      return { ok:true, auction };
    },

    _processAutoBids(auctions, auction, lastBidderId, lastAmount) {
      const autoBids = LocalAdapter._get('autobids') || {};
      Object.entries(autoBids).forEach(([userId, bids]) => {
        if (userId === lastBidderId) return;
        const ab = bids[auction.id];
        if (!ab) return;
        const nextBid = lastAmount + this.getIncrement(lastAmount);
        if (ab.max >= nextBid) {
          auction.bid = nextBid;
          auction.bids++;
          auction.lastBidder = userId;
          Auth._auditLog('autobid_placed', auction.id, `Auto-bid of $${nextBid} placed for ${userId}`);
        }
      });
    },

    setAutoBid(auctionId, userId, maxAmount) {
      const autoBids = LocalAdapter._get('autobids') || {};
      if (!autoBids[userId]) autoBids[userId] = {};
      autoBids[userId][auctionId] = { max: maxAmount, set: Date.now() };
      LocalAdapter._set('autobids', autoBids);
      return { ok:true };
    },

    relist(auctionId, options = {}) {
      const auctions = LocalAdapter._get('auctions') || [];
      const auction = auctions.find(a => a.id === auctionId);
      if (!auction) return { ok:false, error:'Auction not found' };
      // Reset auction state
      auction.bid = options.newStartBid || auction.startBid;
      auction.bids = 0;
      auction.watchers = 0;
      auction.status = 'live';
      auction.endMins = (options.days || 5) * 24 * 60;
      auction.relisted = true;
      auction.relistCount = (auction.relistCount || 0) + 1;
      auction.lastBidder = null;
      if (options.newReserve !== undefined) auction.reserve = options.newReserve;
      LocalAdapter._set('auctions', auctions);
      Auth._auditLog('auction_relisted', auctionId, `Relisted with start bid $${auction.bid}`);
      return { ok:true, auction };
    },

    calculateTotal(winningBid) {
      const settings = LocalAdapter._get('settings') || SEED.settings;
      const premium = winningBid * (settings.buyer_premium_pct / 100);
      const subtotal = winningBid + premium;
      let gst = 0;
      if (settings.gst_mode === 'exclusive') gst = subtotal * (settings.gst_rate / 100);
      const total = subtotal + gst;
      return { winningBid, premium, gst, total, gstInclusive: settings.gst_mode === 'inclusive' };
    }
  };

  /* ── PUBLIC API METHODS ───────────────────────────────────── */
  // All methods call through adapter — swapping adapter swaps backend

  function init() {
    LocalAdapter._seed();
  }

  const settings = {
    get: (key) => { const s = LocalAdapter._get('settings'); return key ? s?.[key] : s; },
    getAll: () => LocalAdapter._get('settings') || SEED.settings,
    update: (updates) => {
      const s = LocalAdapter._get('settings') || {};
      const updated = { ...s, ...updates };
      LocalAdapter._set('settings', updated);
      Auth._auditLog('settings_update', 'platform_settings', `Updated: ${Object.keys(updates).join(', ')}`);
      return { ok:true };
    }
  };

  const content = {
    get: (page) => { const c = LocalAdapter._get('content'); return page ? c?.[page] : c; },
    update: (page, updates) => {
      const c = LocalAdapter._get('content') || {};
      c[page] = { ...c[page], ...updates };
      LocalAdapter._set('content', c);
      return { ok:true };
    }
  };

  const auctions = {
    list: (filters = {}) => {
      let items = LocalAdapter._get('auctions') || [];
      if (filters.state) items = items.filter(a => a.state === filters.state);
      if (filters.status) items = items.filter(a => a.status === filters.status);
      if (filters.facilityId) items = items.filter(a => a.facilityId === filters.facilityId);
      if (filters.featured) items = items.filter(a => a.featured);
      if (filters.q) {
        const q = filters.q.toLowerCase();
        items = items.filter(a => a.name.toLowerCase().includes(q) || a.suburb.toLowerCase().includes(q) || a.facility.toLowerCase().includes(q));
      }
      if (filters.minBid) items = items.filter(a => a.bid >= filters.minBid);
      if (filters.maxBid) items = items.filter(a => a.bid <= filters.maxBid);
      return items;
    },
    get: (id) => (LocalAdapter._get('auctions') || []).find(a => a.id === id),
    bid: (auctionId, userId, amount) => AuctionEngine.placeBid(auctionId, userId, amount),
    setAutoBid: (auctionId, userId, max) => AuctionEngine.setAutoBid(auctionId, userId, max),
    calculateTotal: (bid) => AuctionEngine.calculateTotal(bid),
    relist: (auctionId, opts) => AuctionEngine.relist(auctionId, opts),
    create: (data) => {
      const items = LocalAdapter._get('auctions') || [];
      const auction = { id: 'A'+Date.now(), ...data, bid: data.startBid, bids:0, watchers:0, status:'live', created: new Date().toISOString() };
      items.push(auction);
      LocalAdapter._set('auctions', items);
      Auth._auditLog('auction_created', auction.id, `Created by operator ${data.facilityId}`);
      return { ok:true, auction };
    },
    update: (id, updates) => {
      const items = LocalAdapter._get('auctions') || [];
      const idx = items.findIndex(a => a.id === id);
      if (idx < 0) return { ok:false, error:'Not found' };
      items[idx] = { ...items[idx], ...updates };
      LocalAdapter._set('auctions', items);
      return { ok:true, auction:items[idx] };
    },
    cancel: (id, reason) => {
      const result = auctions.update(id, { status:'cancelled', cancelReason:reason });
      if (result.ok) Auth._auditLog('auction_cancelled', id, reason);
      return result;
    },
    feature: (id, featured) => {
      const result = auctions.update(id, { featured });
      if (result.ok) Auth._auditLog(featured?'auction_featured':'auction_unfeatured', id, '');
      return result;
    }
  };

  const users = {
    getBuyers: () => (LocalAdapter._get('users') || { buyers:[] }).buyers,
    getOperators: () => (LocalAdapter._get('users') || { operators:[] }).operators || [],
    getUser: (id) => {
      const { buyers=[], operators=[] } = LocalAdapter._get('users') || {};
      return [...buyers, ...operators].find(u => u.id === id);
    },
    suspend: (id, reason, days) => {
      const { buyers=[], operators=[] } = LocalAdapter._get('users') || {};
      const suspendedUntil = new Date(Date.now() + days*24*60*60*1000).toISOString();
      const update = u => u.id===id ? {...u, status:'suspended', suspendReason:reason, suspendedUntil} : u;
      LocalAdapter._set('users', { buyers: buyers.map(update), operators: operators.map(update) });
      Auth._auditLog('suspend_user', id, `Suspended for ${days} days: ${reason}`);
      return { ok:true };
    },
    block: (id, reason) => {
      const { buyers=[], operators=[] } = LocalAdapter._get('users') || {};
      const update = u => u.id===id ? {...u, status:'blocked', blockReason:reason} : u;
      LocalAdapter._set('users', { buyers: buyers.map(update), operators: operators.map(update) });
      Auth._auditLog('block_user', id, `Permanently blocked: ${reason}`);
      return { ok:true };
    },
    unsuspend: (id) => {
      const { buyers=[], operators=[] } = LocalAdapter._get('users') || {};
      const update = u => u.id===id ? {...u, status:'active', suspendReason:null, suspendedUntil:null} : u;
      LocalAdapter._set('users', { buyers: buyers.map(update), operators: operators.map(update) });
      Auth._auditLog('unsuspend_user', id, `User reinstated`);
      return { ok:true };
    },
    warn: (id, message) => {
      Auth._auditLog('warn_user', id, `Warning issued: ${message}`);
      return { ok:true };
    }
  };

  const facilities = {
    list: (status) => { let f = LocalAdapter._get('facilities') || []; return status ? f.filter(x=>x.status===status) : f; },
    get: (id) => (LocalAdapter._get('facilities') || []).find(f => f.id === id),
    approve: (id) => {
      const facs = LocalAdapter._get('facilities') || [];
      const f = facs.find(x=>x.id===id);
      if (!f) return { ok:false };
      f.status='approved'; f.approvedAt=new Date().toISOString();
      LocalAdapter._set('facilities', facs);
      Auth._auditLog('approve_facility', id, `Approved: ${f.name}`);
      return { ok:true };
    },
    reject: (id, reason) => {
      const facs = LocalAdapter._get('facilities') || [];
      const f = facs.find(x=>x.id===id);
      if (!f) return { ok:false };
      f.status='rejected'; f.rejectReason=reason; f.rejectedAt=new Date().toISOString();
      LocalAdapter._set('facilities', facs);
      Auth._auditLog('reject_facility', id, `Rejected: ${f.name} — ${reason}`);
      return { ok:true };
    },
    register: (data) => {
      const facs = LocalAdapter._get('facilities') || [];
      const facility = { id:'F'+Date.now(), ...data, status:'pending', joined:new Date().toISOString() };
      facs.push(facility);
      LocalAdapter._set('facilities', facs);
      return { ok:true, facility };
    }
  };

  const emailTemplates = {
    getAll: () => LocalAdapter._get('emailTemplates') || SEED.emailTemplates,
    get: (id) => (LocalAdapter._get('emailTemplates') || {})[id],
    update: (id, updates) => {
      const templates = LocalAdapter._get('emailTemplates') || {};
      templates[id] = { ...templates[id], ...updates };
      LocalAdapter._set('emailTemplates', templates);
      Auth._auditLog('update_email_template', id, `Template updated: ${id}`);
      return { ok:true };
    },
    preview: (id, vars = {}) => {
      const t = emailTemplates.get(id);
      if (!t) return null;
      let body = t.body;
      let subject = t.subject;
      const sampleVars = {
        first_name:'Jane', facility_name:'Storage King Moorabbin', state:'VIC',
        auction_name:'Unit 12A — Furniture & White Goods', current_bid:'340',
        winning_bid:'340', premium_pct:'10', premium_amount:'34', total_amount:'374',
        gst_note:'GST inclusive', payment_url:'https://pay.example.com/xyz',
        payment_window_hours:'24', collection_window_hours:'72',
        collection_deadline:'17 March 2025 5:00 PM', collection_ref:'COL-A002-B002',
        facility_address:'2 Warehouse Dr, Moorabbin VIC 3189', facility_phone:'03 9000 0000',
        platform_url:'https://www.selfstorageauctions.com.au', auction_url:'https://www.selfstorageauctions.com.au/auction/A002',
        platform_name:'SelfStorageAuctions.com.au', support_email:'support@selfstorageauctions.com.au',
        operator_fee:'99', trial_end_date:'14 April 2025', buyer_ref:'B002',
        operator_payout:'340', payout_days:'2', payment_deadline:'15 March 2025 5:00 PM',
        auction_short_name:'Unit 12A', time_remaining:'38 minutes', short_url:'ssa.au/A002',
        contact_name:'Sarah K.', facility_hours:'Mon-Sat 8am-6pm',
        ...vars
      };
      Object.entries(sampleVars).forEach(([k,v]) => {
        const re = new RegExp(`\\{\\{${k}\\}\\}`, 'g');
        body = body.replace(re, v);
        subject = subject.replace(re, v);
      });
      return { subject, body };
    }
  };

  const smsTemplates = {
    getAll: () => LocalAdapter._get('smsTemplates') || SEED.smsTemplates,
    get: (id) => (LocalAdapter._get('smsTemplates') || {})[id],
    update: (id, updates) => {
      const templates = LocalAdapter._get('smsTemplates') || {};
      templates[id] = { ...templates[id], ...updates };
      LocalAdapter._set('smsTemplates', templates);
      return { ok:true };
    }
  };

  const watchlist = {
    get: (userId) => (LocalAdapter._get(`watchlist_${userId}`) || []),
    toggle: (userId, auctionId) => {
      const wl = watchlist.get(userId);
      const i = wl.indexOf(auctionId);
      if (i>-1) wl.splice(i,1); else wl.push(auctionId);
      LocalAdapter._set(`watchlist_${userId}`, wl);
      return { watching: wl.includes(auctionId) };
    }
  };

  const alerts = {
    get: (userId) => (LocalAdapter._get(`alerts_${userId}`) || { rules:[] }),
    save: (userId, rule) => {
      const prefs = alerts.get(userId);
      prefs.rules = prefs.rules || [];
      prefs.rules.push({ ...rule, id:Date.now(), created:new Date().toISOString() });
      LocalAdapter._set(`alerts_${userId}`, prefs);
      return { ok:true };
    },
    delete: (userId, ruleId) => {
      const prefs = alerts.get(userId);
      prefs.rules = prefs.rules.filter(r => r.id !== ruleId);
      LocalAdapter._set(`alerts_${userId}`, prefs);
      return { ok:true };
    }
  };

  const audit = {
    getLog: () => LocalAdapter._get('auditLog') || [],
    log: (action, target, details) => Auth._auditLog(action, target, details)
  };

  /* ── HELPERS ──────────────────────────────────────────────── */
  function formatTime(mins) {
    if (mins <= 0) return 'Ended';
    if (mins < 60) return `${mins}m`;
    if (mins < 1440) { const h=Math.floor(mins/60), m=mins%60; return m?`${h}h ${m}m`:`${h}h`; }
    const d=Math.floor(mins/1440), h=Math.floor((mins%1440)/60);
    return h?`${d}d ${h}h`:`${d}d`;
  }

  function formatCurrency(amount) {
    return new Intl.NumberFormat('en-AU', { style:'currency', currency:'AUD' }).format(amount);
  }

  function toast(msg, type='', duration=3500) {
    let container = document.querySelector('.ssa-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'ssa-toast-container';
      document.body.appendChild(container);
    }
    const el = document.createElement('div');
    el.className = `ssa-toast ssa-toast--${type}`;
    const icons = { success:'✓', danger:'✕', warning:'⚠', '':'ℹ' };
    el.innerHTML = `<span class="ssa-toast__icon">${icons[type]||'ℹ'}</span><span>${msg}</span>`;
    container.appendChild(el);
    setTimeout(() => { el.style.opacity='0'; el.style.transform='translateX(100%)'; setTimeout(()=>el.remove(), 300); }, duration);
  }

  // Initialize on load
  init();

  return {
    Auth, settings, content, auctions, users, facilities,
    emailTemplates, smsTemplates, watchlist, alerts, audit,
    formatTime, formatCurrency, toast,
    SEED // Exposed for debugging
  };
})();

// Global shorthand
window.SSA = API;
