/* ══════════════════════════════════════════════════════
   SelfStorageAuctions.com.au — Shared App JS
══════════════════════════════════════════════════════ */
const SSA = (function () {

  /* ── AUCTION DATA ────────────────────────────────── */
  const AUCTIONS = [
    { id:'A001', facility:'Kennards Self Storage', state:'NSW', suburb:'Parramatta', emoji:'📦', name:'Unit 4B — Household Goods, Furniture & Personal Items', bid:185, bids:12, watchers:23, endMins:134, featured:true, badge:'live', description:'Mixed household items including bedroom furniture, clothing, boxes of personal items and kitchenware. Unit appears to contain some quality pieces visible at front.' },
    { id:'A002', facility:'Storage King', state:'VIC', suburb:'Moorabbin', emoji:'🛋️', name:'Unit 12A — Furniture, White Goods & Power Tools', bid:340, bids:27, watchers:41, endMins:38, featured:true, badge:'ending', description:'Large unit containing lounge suite, refrigerator, washing machine, assorted power tools and garden equipment.' },
    { id:'A003', facility:'National Storage', state:'QLD', suburb:'Fortitude Valley', emoji:'🎸', name:'Unit 7C — Electronics, Musical Instruments & Collectibles', bid:520, bids:3, watchers:67, endMins:4686, featured:true, badge:'new', description:'Compact but densely packed unit with electronics, what appears to be guitar equipment, and several labelled collectible boxes.' },
    { id:'A004', facility:'Fort Knox Storage', state:'WA', suburb:'Osborne Park', emoji:'🔧', name:'Unit 3D — Workshop Tools, Garden & Camping Equipment', bid:110, bids:9, watchers:14, endMins:1680, featured:false, badge:'live', description:'Full workshop setup including hand tools, power tools, garden equipment and camping gear. Viewing by appointment.' },
    { id:'A005', facility:'Wilson Storage', state:'NSW', suburb:'Artarmon', emoji:'👗', name:'Unit 9E — Fashion, Clothing & Retail Overstock', bid:75, bids:5, watchers:19, endMins:352, featured:false, badge:'live', description:'Large selection of clothing, accessories and what appears to be retail overstock including sealed boxes.' },
    { id:'A006', facility:'Casey Self Storage', state:'SA', suburb:'Glenelg', emoji:'📚', name:'Unit 2A — Books, Office Equipment & Filing', bid:25, bids:1, watchers:7, endMins:6511, featured:false, badge:'new', description:'Rows of boxed books, office furniture, filing cabinets and computer equipment.' },
    { id:'A007', facility:'StowHub', state:'NSW', suburb:'Rouse Hill', emoji:'🏠', name:'Unit 6F — Moving Unit — Full House Contents', bid:890, bids:19, watchers:88, endMins:720, featured:true, badge:'live', description:'Premium unit packed to the ceiling with quality furniture, artwork, kitchen equipment and personal items. Significant lot.' },
    { id:'A008', facility:'Kennards Self Storage', state:'QLD', suburb:'Newstead', emoji:'💼', name:'Unit 1C — Business Equipment & Office Fit-Out', bid:240, bids:8, watchers:31, endMins:2160, featured:false, badge:'live', description:'Office desks, chairs, computers, server rack components, filing systems and business equipment.' },
    { id:'A009', facility:'Storage King', state:'NSW', suburb:'Penrith', emoji:'🚲', name:'Unit 8B — Sports, Bikes & Outdoor Equipment', bid:155, bids:14, watchers:26, endMins:95, featured:false, badge:'ending', description:'Multiple bicycles, gym equipment, kayak, surfboards and extensive sporting goods.' },
    { id:'A010', facility:'National Storage', state:'VIC', suburb:'Dandenong', emoji:'🎨', name:'Unit 11D — Art, Antiques & Vintage Items', bid:610, bids:22, watchers:104, endMins:510, featured:false, badge:'live', description:'Carefully packed unit containing framed artworks, ornamental pieces, vintage furniture and several clearly labelled antique boxes.' },
    { id:'A011', facility:'Fort Knox Storage', state:'QLD', suburb:'Loganholme', emoji:'🍳', name:'Unit 5A — Kitchen & Homewares', bid:45, bids:4, watchers:11, endMins:3024, featured:false, badge:'new', description:'Kitchen appliances, cookware, crockery sets, small appliances and homewares.' },
    { id:'A012', facility:'Wilson Storage', state:'WA', suburb:'Balcatta', emoji:'📷', name:'Unit 14C — Photography & Creative Studio Equipment', bid:730, bids:16, watchers:92, endMins:1440, featured:false, badge:'live', description:'Professional photography equipment, lighting rigs, backdrops, lenses and creative studio accessories.' },
  ];

  /* ── AUTH HELPERS ────────────────────────────────── */
  const Auth = {
    getBuyer:()=>{ try{return JSON.parse(localStorage.getItem('ssa_buyer')||'null')}catch{return null} },
    setBuyer:(d)=>localStorage.setItem('ssa_buyer',JSON.stringify(d)),
    getOperator:()=>{ try{return JSON.parse(localStorage.getItem('ssa_operator')||'null')}catch{return null} },
    setOperator:(d)=>localStorage.setItem('ssa_operator',JSON.stringify(d)),
    getAdmin:()=>localStorage.getItem('ssa_admin')==='true',
    setAdmin:()=>localStorage.setItem('ssa_admin','true'),
    logout:()=>{ localStorage.removeItem('ssa_buyer');localStorage.removeItem('ssa_operator');localStorage.removeItem('ssa_admin'); },
    getWatchlist:()=>{ try{return JSON.parse(localStorage.getItem('ssa_watchlist')||'[]')}catch{return []} },
    toggleWatch:(id)=>{
      const wl=Auth.getWatchlist();
      const i=wl.indexOf(id);
      if(i>-1) wl.splice(i,1); else wl.push(id);
      localStorage.setItem('ssa_watchlist',JSON.stringify(wl));
      return wl.includes(id);
    },
    getAutobids:()=>{ try{return JSON.parse(localStorage.getItem('ssa_autobids')||'{}')}catch{return {}} },
    setAutobid:(id,max)=>{ const ab=Auth.getAutobids(); ab[id]=max; localStorage.setItem('ssa_autobids',JSON.stringify(ab)); },
    getPrefs:()=>{ try{return JSON.parse(localStorage.getItem('ssa_prefs')||'null')}catch{return null} },
    setPrefs:(p)=>localStorage.setItem('ssa_prefs',JSON.stringify(p)),
  };

  /* ── TOAST ───────────────────────────────────────── */
  function toast(msg, type='', duration=3200) {
    let container=document.querySelector('.toast-container');
    if(!container){
      container=document.createElement('div');
      container.className='toast-container';
      document.body.appendChild(container);
    }
    const el=document.createElement('div');
    el.className=`toast toast--${type}`;
    el.innerHTML=`<span>${type==='success'?'✓':type==='danger'?'✕':'ℹ'}</span>${msg}`;
    container.appendChild(el);
    setTimeout(()=>{ el.style.opacity='0'; el.style.transform='translateX(100%)'; el.style.transition='.25s ease'; setTimeout(()=>el.remove(),250); },duration);
  }

  /* ── TIME UTILS ──────────────────────────────────── */
  function formatTime(mins) {
    if(mins<=0) return 'Ended';
    if(mins<60) return `${mins}m`;
    if(mins<1440) { const h=Math.floor(mins/60),m=mins%60; return m?`${h}h ${m}m`:`${h}h`; }
    const d=Math.floor(mins/1440),h=Math.floor((mins%1440)/60);
    return h?`${d}d ${h}h`:`${d}d`;
  }

  function startCountdowns() {
    const timers=document.querySelectorAll('[data-countdown]');
    if(!timers.length) return;
    const ends={};
    timers.forEach(el=>{
      const mins=parseInt(el.dataset.countdown)||0;
      ends[el.dataset.id||Math.random()]={el, secs:mins*60};
    });
    setInterval(()=>{
      Object.values(ends).forEach(t=>{
        if(t.secs>0) t.secs--;
        const mins=Math.floor(t.secs/60);
        t.el.textContent=formatTime(mins);
        t.el.classList.toggle('urgent', t.secs<3600);
      });
    },1000);
  }

  /* ── AUCTION CARD HTML ───────────────────────────── */
  function auctionCardHTML(a, opts={}) {
    const wl=Auth.getWatchlist();
    const watching=wl.includes(a.id);
    const featured=a.featured&&opts.showFeatured;
    return `
    <div class="auction-card${featured?' auction-card--featured':''}" data-id="${a.id}" data-state="${a.state.toLowerCase()}" data-facility="${a.facility.toLowerCase()}" onclick="SSA.openBidModal('${a.id}')">
      <div class="auction-card__img">
        ${a.emoji}
        <div class="auction-card__img-overlay"></div>
        <div class="auction-card__badges">
          <span class="badge badge-${a.badge}">${a.badge==='live'?'LIVE':a.badge==='ending'?'ENDING SOON':'NEW'}</span>
        </div>
        ${featured?'<div class="auction-card__featured-banner">⭐ Featured</div>':''}
        <button class="auction-card__watch ${watching?'active':''}" onclick="event.stopPropagation();SSA.toggleWatch('${a.id}',this)" title="Watch this auction">${watching?'❤️':'🤍'}</button>
      </div>
      <div class="auction-card__body">
        <div class="auction-card__facility">${a.facility}</div>
        <div class="auction-card__name">${a.name}</div>
        <div class="auction-card__loc"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>${a.suburb}, ${a.state}</div>
        <div class="auction-card__bids"><strong>${a.bids} bids</strong> · ${a.watchers} watching</div>
        <div class="auction-card__hr"></div>
        <div class="auction-card__foot">
          <div><div class="auction-card__bid-lbl">Current Bid</div><div class="auction-card__bid-val">$${a.bid.toLocaleString()}.00</div></div>
          <div><div class="auction-card__timer-lbl">Time Left</div><div class="auction-card__timer-val${a.endMins<60?' urgent':''}" data-countdown="${a.endMins}" data-id="${a.id}">${formatTime(a.endMins)}</div></div>
        </div>
        <button class="auction-card__cta">View & Bid →</button>
      </div>
    </div>`;
  }

  /* ── BID MODAL ───────────────────────────────────── */
  function openBidModal(id) {
    const a=AUCTIONS.find(x=>x.id===id);
    if(!a) return;
    const buyer=Auth.getBuyer();
    const ab=Auth.getAutobids();
    const autobidVal=ab[id]||'';
    const modal=document.getElementById('bidModal');
    if(!modal) return;
    modal.querySelector('.modal__title').textContent=a.name;
    modal.querySelector('#bidAuctionId').value=id;
    modal.querySelector('#bidCurrentVal').textContent='$'+a.bid.toLocaleString()+'.00';
    modal.querySelector('#bidMinVal').textContent='$'+(a.bid+5)+'.00';
    modal.querySelector('#bidAmount').value='';
    modal.querySelector('#autobidAmount').value=autobidVal;
    modal.querySelector('#bidFacility').textContent=`${a.facility} · ${a.suburb}, ${a.state}`;
    modal.querySelector('#bidDescription').textContent=a.description;
    const buyerPremium=document.getElementById('bidBuyerPremium');
    if(buyerPremium) buyerPremium.textContent='10%';
    if(!buyer){
      modal.querySelector('#bidLoggedIn').style.display='none';
      modal.querySelector('#bidNotLoggedIn').style.display='block';
    } else {
      modal.querySelector('#bidLoggedIn').style.display='block';
      modal.querySelector('#bidNotLoggedIn').style.display='none';
    }
    document.getElementById('bidModalOverlay').classList.add('open');
  }

  function closeBidModal() {
    document.getElementById('bidModalOverlay').classList.remove('open');
  }

  function placeBid() {
    const buyer=Auth.getBuyer();
    if(!buyer){ toast('Please register or log in to bid','danger'); return; }
    const id=document.getElementById('bidAuctionId').value;
    const amount=parseFloat(document.getElementById('bidAmount').value);
    const a=AUCTIONS.find(x=>x.id===id);
    if(!amount||amount<=a.bid){ toast('Bid must be higher than current bid','danger'); return; }
    a.bid=amount; a.bids++;
    closeBidModal();
    toast(`Bid of $${amount.toFixed(2)} placed on ${a.id}! 🎉`,'success');
    // refresh any visible cards
    document.querySelectorAll(`[data-id="${id}"]`).forEach(el=>{
      if(el.classList.contains('auction-card__bid-val')) el.textContent='$'+amount.toLocaleString()+'.00';
    });
  }

  function saveAutobid() {
    const buyer=Auth.getBuyer();
    if(!buyer){ toast('Please log in to set auto-bids','danger'); return; }
    const id=document.getElementById('bidAuctionId').value;
    const max=parseFloat(document.getElementById('autobidAmount').value);
    if(!max||max<=0){ toast('Please enter a valid maximum bid','danger'); return; }
    Auth.setAutobid(id,max);
    toast(`Auto-bid set to $${max.toFixed(2)} for ${id}`,'success');
    closeBidModal();
  }

  /* ── WATCH ───────────────────────────────────────── */
  function toggleWatch(id, btn) {
    const buyer=Auth.getBuyer();
    if(!buyer){ toast('Log in to save to watchlist','danger'); return; }
    const watching=Auth.toggleWatch(id);
    btn.textContent=watching?'❤️':'🤍';
    btn.classList.toggle('active',watching);
    toast(watching?'Added to watchlist':'Removed from watchlist', watching?'success':'');
  }

  /* ── NAV HTML ────────────────────────────────────── */
  function navHTML(active) {
    const buyer=Auth.getBuyer();
    const op=Auth.getOperator();
    const liveCount=AUCTIONS.filter(a=>a.badge==='live'||a.badge==='ending').length;
    const userMenu=buyer
      ? `<a href="/buyer-portal/" class="btn btn-outline btn-sm">👤 ${buyer.name.split(' ')[0]}</a><button onclick="SSA.logout()" class="btn btn-ghost btn-sm">Log Out</button>`
      : op
      ? `<a href="/operator-portal/" class="btn btn-outline btn-sm">🏢 Operator</a><button onclick="SSA.logout()" class="btn btn-ghost btn-sm">Log Out</button>`
      : `<a href="/buyer-portal/" class="btn btn-outline btn-sm">Log In</a><a href="/buyer-portal/" class="btn btn-primary btn-sm">Register Free</a>`;
    const links=[
      {href:'/auctions/',label:'Live Auctions',key:'auctions'},
      {href:'/blog/',label:'Blog',key:'blog'},
      {href:'/operator-portal/',label:'For Operators',key:'operator'},
      {href:'/contact/',label:'Help',key:'contact'},
    ];
    const linkHTML=links.map(l=>`<a href="${l.href}" class="nav__link${active===l.key?' active':''}">${l.label}</a>`).join('');
    return `
    <nav class="nav">
      <div class="nav__inner">
        <a href="/" class="nav__logo">
          <div class="nav__logo-mark"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="1" y="5" width="16" height="11" rx="2" stroke="#F4A233" stroke-width="1.5"/><path d="M5 5V4a4 4 0 0 1 8 0v1" stroke="#F4A233" stroke-width="1.5" stroke-linecap="round"/><circle cx="9" cy="10.5" r="1.5" fill="#F4A233"/></svg></div>
          <span class="nav__logo-text">SelfStorage<span>Auctions</span></span>
        </a>
        <div class="nav__links">${linkHTML}</div>
        <div class="nav__actions">
          <span class="nav__live">🔴 ${liveCount} Live</span>
          ${userMenu}
        </div>
        <div class="nav__hamburger" onclick="this.closest('nav').querySelector('.nav__mobile').classList.toggle('open')">
          <span></span><span></span><span></span>
        </div>
      </div>
      <div class="nav__mobile">
        ${linkHTML}
        <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px">${userMenu}</div>
      </div>
    </nav>`;
  }

  /* ── FOOTER HTML ─────────────────────────────────── */
  function footerHTML() {
    return `
    <footer class="footer">
      <div class="container">
        <div class="footer__grid">
          <div>
            <div class="footer__brand-name">SelfStorage<span>Auctions</span>.com.au</div>
            <div class="footer__tagline">Hunt. Find. Bid. Score.</div>
            <p class="footer__desc">Australia's modern, transparent self storage auction platform — built for operators who want results and buyers who want bargains.</p>
            <div class="footer__badge">🔒 SSL Secured · Australian Owned & Operated</div>
          </div>
          <div>
            <div class="footer__col-title">For Buyers</div>
            <div class="footer__links">
              <a href="/auctions/">Browse Auctions</a>
              <a href="/buyer-portal/">Buyer Portal</a>
              <a href="/buyer-portal/#alerts">Set Up Alerts</a>
              <a href="/buyer-portal/#autobid">Auto-Bid</a>
              <a href="/contact/#faq">FAQs</a>
            </div>
          </div>
          <div>
            <div class="footer__col-title">For Operators</div>
            <div class="footer__links">
              <a href="/operator-portal/">Operator Portal</a>
              <a href="/operator-portal/#pricing">Pricing</a>
              <a href="/operator-portal/#list">List a Facility</a>
              <a href="/operator-portal/#reports">Reports</a>
              <a href="/contact/">Operator Support</a>
            </div>
          </div>
          <div>
            <div class="footer__col-title">Company</div>
            <div class="footer__links">
              <a href="/blog/">Blog</a>
              <a href="/contact/">Contact Us</a>
              <a href="/terms/">Terms & Conditions</a>
              <a href="/terms/#privacy">Privacy Policy</a>
              <a href="/admin/">Admin</a>
            </div>
          </div>
        </div>
        <div class="footer__bottom">
          <div class="footer__copy">© 2025 SelfStorageAuctions.com.au · All rights reserved · ABN XX XXX XXX XXX · GST inclusive</div>
          <div class="footer__legal"><a href="/terms/">Terms</a><a href="/terms/#privacy">Privacy</a><a href="/terms/#auction-rules">Auction Rules</a></div>
        </div>
      </div>
    </footer>`;
  }

  /* ── BID MODAL HTML ──────────────────────────────── */
  function bidModalHTML() {
    return `
    <div class="modal-overlay" id="bidModalOverlay" onclick="if(event.target===this)SSA.closeBidModal()">
      <div class="modal modal--wide" id="bidModal">
        <div class="modal__header">
          <span class="modal__title">Place a Bid</span>
          <button class="modal__close" onclick="SSA.closeBidModal()">✕</button>
        </div>
        <div class="modal__body">
          <input type="hidden" id="bidAuctionId"/>
          <div style="background:var(--cloud);border-radius:var(--r-md);padding:14px;margin-bottom:20px">
            <div style="font-size:.78rem;font-weight:700;color:var(--amber);margin-bottom:4px" id="bidFacility"></div>
            <p style="font-size:.84rem;color:var(--muted);margin:0" id="bidDescription"></p>
          </div>
          <div class="field-row" style="margin-bottom:20px">
            <div class="card-flat" style="text-align:center">
              <div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:6px">Current Bid</div>
              <div style="font-size:1.6rem;font-weight:800;color:var(--amber)" id="bidCurrentVal">$0</div>
            </div>
            <div class="card-flat" style="text-align:center">
              <div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:6px">Minimum Bid</div>
              <div style="font-size:1.6rem;font-weight:800;color:var(--navy)" id="bidMinVal">$0</div>
            </div>
          </div>
          <div id="bidNotLoggedIn" style="display:none">
            <div class="alert alert-warning"><span class="alert-icon">⚠️</span>You need to <a href="/buyer-portal/" style="font-weight:700;color:var(--warning);text-decoration:underline">register or log in</a> to place a bid.</div>
          </div>
          <div id="bidLoggedIn">
            <div class="form-group">
              <label>Your Bid ($AUD incl. GST)</label>
              <div class="input-group">
                <span style="display:flex;align-items:center;padding:0 12px;background:var(--cloud);border:1.5px solid var(--border);border-right:none;border-radius:var(--r-md) 0 0 var(--r-md);font-weight:700;color:var(--muted)">$</span>
                <input type="number" class="form-control" id="bidAmount" placeholder="Enter your bid amount" min="0" step="5"/>
                <button class="btn btn-primary" onclick="SSA.placeBid()">Place Bid</button>
              </div>
              <div class="form-hint">Buyer's premium: <strong id="bidBuyerPremium">10%</strong> applied at checkout. All prices include GST.</div>
            </div>
            <div class="divider"></div>
            <div class="form-group">
              <label>Auto-Bid — Maximum Amount ($AUD)</label>
              <div class="input-group">
                <span style="display:flex;align-items:center;padding:0 12px;background:var(--cloud);border:1.5px solid var(--border);border-right:none;border-radius:var(--r-md) 0 0 var(--r-md);font-weight:700;color:var(--muted)">$</span>
                <input type="number" class="form-control" id="autobidAmount" placeholder="Set your maximum — we'll bid for you" min="0" step="5"/>
                <button class="btn btn-navy" onclick="SSA.saveAutobid()">Set Auto-Bid</button>
              </div>
              <div class="form-hint">We'll automatically bid the minimum needed to keep you in the lead, up to your maximum.</div>
            </div>
          </div>
        </div>
      </div>
    </div>`;
  }

  /* ── INIT ────────────────────────────────────────── */
  function init(page) {
    // Inject nav
    const navEl=document.getElementById('ssa-nav');
    if(navEl) navEl.outerHTML=navHTML(page);
    // Inject footer
    const footEl=document.getElementById('ssa-footer');
    if(footEl) footEl.outerHTML=footerHTML();
    // Inject bid modal
    if(!document.getElementById('bidModalOverlay')) document.body.insertAdjacentHTML('beforeend',bidModalHTML());
    // Start countdowns
    startCountdowns();
    // Smooth scroll for hash links
    document.querySelectorAll('a[href^="#"]').forEach(a=>{
      a.addEventListener('click',e=>{
        const t=document.querySelector(a.getAttribute('href'));
        if(t){e.preventDefault();t.scrollIntoView({behavior:'smooth',block:'start'});}
      });
    });
  }

  function logout() {
    Auth.logout();
    toast('Logged out successfully');
    setTimeout(()=>location.href='/',800);
  }

  return { init, Auth, AUCTIONS, toast, auctionCardHTML, formatTime, openBidModal, closeBidModal, placeBid, saveAutobid, toggleWatch, logout };
})();
